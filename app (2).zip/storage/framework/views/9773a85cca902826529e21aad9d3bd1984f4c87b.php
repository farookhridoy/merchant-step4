<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Title  -->
    <title>Apply now for primium merchant funding </title>
    <!-- Favicon  -->
    <link rel="icon" href="<?php echo e(asset('logo')); ?>/logo.png">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/style.css">
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
    <!--<header class="header_area">-->
    <!--    <div class="bigshop-main-menu">-->
    <!--        <div class="container">-->
    <!--            <div class="classy-nav-container breakpoint-off">-->
    <!--                <nav class="classy-navbar" id="bigshopNav">-->

    <!--                     Nav Brand -->
    <!--                    <a href="<?php echo e(URL::to('/')); ?>" class="nav-brand">-->
    <!--                        <img style="height:60px !important" src="<?php echo e(asset('logo')); ?>/logo.png" alt="logo">-->
    <!--                    </a>-->

    <!--                     Toggler -->
    <!--                    <div class="classy-navbar-toggler">-->
    <!--                        <span class="navbarToggler">-->
    <!--                            <span></span>-->
    <!--                            <span></span>-->
    <!--                            <span></span>-->
    <!--                        </span>-->
    <!--                    </div>-->
    <!--                     Menu -->
    <!--                    <div class="classy-menu">-->
    <!--                        <div class="classynav">-->
    <!--                            <ul>-->
    <!--                                <li><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>-->
    <!--                            </ul>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                </nav>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</header>-->
    
    <main>
       <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="<?php echo e(asset('assets')); ?>/js/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/popper.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jquery.easing.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/default/classy-nav.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/owl.carousel.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/default/scrollup.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/waypoints.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jquery.countdown.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jquery.counterup.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jquery-ui.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jarallax.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jarallax-video.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jquery.nice-select.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/wow.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/default/active.js"></script>
    <script>
        setTimeout(function(){
          $('#alert').slideUp()
        },4000)
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH E:\laragon\www\Personal\merchant-step4\resources\views/partials/master.blade.php ENDPATH**/ ?>