<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\Session;

if (Session::has('homepage')) {
    $homepage = Session::get('homepage');

    //dd($homepage);
}
?>
<section>
    <div class="container">
        <div class="text-center">
            <div class="row">
                <div class="col-12">
                    <h3 class="font-weight-bold">4 steps to funding</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <p class="text-center">Thank you for placing your trust in us. Please take a few minutes to complete the form below. We will process your request in 24-48 business hours.</p>
                </div>
            </div>
        </div>
        <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>

<!-- Checkout Steps Area -->
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="checkout_steps_area">
                <a class="active" href="#">BUSINESS INFORMATION</a>
                <a href="#">MERCHANT/OWNER INFORMATION</a>
                <a href="#">PARTNER /OWNER INFORMATION</a>
                <a href="#">BUSINESS PROPERTY INFORMATION</a>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <form method="POST" action="<?php echo e(route('submit_first_step')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="checkout_area section_padding_100_50">
            <div class="container">
                <div class="row mt-5">
                    <div class="col-12 col-md-6">
                        <div class="form-group">
                            <span class="">Legal/Corporate Name <span class="text-danger">*</span></span>

                            <input type="text" class="form-control" placeholder="Legal/Corporate Name" name="business_name" required value="<?php echo e(old('business_name', isset($homepage) ? $homepage['business_name']:'')); ?>">

                            <?php $__errorArgs = ['business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="col-12 col-md-6">
                        <div class="form-group">
                            <span class="">DBA</span>
                            <input type="text" class="form-control" placeholder="DBA"
                            name="business_date_of_birth" value="<?php echo e(old('business_date_of_birth', isset($homepage) ? $homepage['business_date_of_birth'] :'')); ?>">
                            <?php $__errorArgs = ['business_date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="form-group">
                            <span class="">Address <span class="text-danger">*</span></span>
                            <textarea type="textarea" class="form-control"  name="business_address" required>
                                <?php echo e(old('business_address',isset($homepage) ? $homepage['business_address'] :'')); ?>

                            </textarea>

                            <?php $__errorArgs = ['business_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="form-group">
                            <span class="">City <span class="text-danger">*</span></span>

                            <input type="text" class="form-control" placeholder="City" name="business_city" required value="<?php echo e(old('business_city', isset($homepage) ? $homepage['business_city']:'')); ?>">

                            <?php $__errorArgs = ['business_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="form-group">
                            <span class="">State <span class="text-danger">*</span></span>

                            <input type="text" class="form-control" placeholder="State" name="business_state" required value="<?php echo e(old('business_state', isset($homepage) ? $homepage['business_state']:'')); ?>">

                            <?php $__errorArgs = ['business_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="form-group">
                            <span class="">Zip <span class="text-danger">*</span></span>

                            <input type="text" class="form-control" placeholder="Zip" name="business_zip" required value="<?php echo e(old('business_zip', isset($homepage) ? $homepage['business_zip']:'')); ?>">
                            <?php $__errorArgs = ['business_zip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Telephone #<span class="text-danger">*</span></span>
                            <input type="number" min="11" class="form-control" placeholder="Telephone" name="business_phone"
                            required value="<?php echo e(old('business_phone',isset($homepage) ? $homepage['business_phone'] :'')); ?>">
                            <?php $__errorArgs = ['business_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Fax #<span class="text-danger">*</span></span>
                            <input type="number" min="11" class="form-control" placeholder="Phone No" name="business_fax"
                            required value="<?php echo e(old('business_fax',isset($homepage) ? $homepage['business_fax'] :'')); ?>">
                            <?php $__errorArgs = ['business_fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Federal Tax ID<span class="text-danger">*</span></span>
                            <input type="text" class="form-control" placeholder="Fax" name="federal_tax_id"
                            required value="<?php echo e(old('federal_tax_id',isset($homepage) ? $homepage['federal_tax_id'] :'')); ?>">
                            <?php $__errorArgs = ['federal_tax_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Date Business Started<span class="text-danger">*</span></span>
                            <input type="date" class="form-control" placeholder="Date Business Started" required
                            name="businesss_start_date" value="<?php echo e(old('businesss_start_date', isset($homepage) ? $homepage['businesss_start_date'] :'')); ?>">
                            <?php $__errorArgs = ['businesss_start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                     <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Length of Ownership: %<span class="text-danger">*</span></span>
                            <input type="number" class="form-control" placeholder="Length of Ownership: %" name="lenght_of_ownership" required value="<?php echo e(old('lenght_of_ownership',isset($homepage) ? $homepage['lenght_of_ownership'] :'')); ?>">
                            <?php $__errorArgs = ['merchant_ownership'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                     <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Website</span>
                            <input type="text" class="form-control" placeholder="Website" name="website"
                             value="<?php echo e(old('website',isset($homepage) ? $homepage['website'] :'')); ?>">
                            <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12 col-md-8">
                        <div class="form-group">
                            <span class="">Type of Entity (circle one) <span class="text-danger">*</span></span>
                            <br>
                            <input type="radio" id="SoleProprietorship" name="type_of_entity" value="Sole Proprietorship" <?php echo e(isset($homepage)? ($homepage['type_of_entity'] === "Sole Proprietorship") ? 'checked' : '':''); ?>>
                            <label for="SoleProprietorship">Sole Proprietorship</label>&nbsp;&nbsp;&nbsp;

                            <input type="radio" id="Partnership" name="type_of_entity" value="Partnership" <?php echo e(isset($homepage)? ($homepage['type_of_entity'] == "Partnership") ? 'checked=checked' : '':''); ?>>
                            <label for="Partnership"> Partnership</label>&nbsp;&nbsp;&nbsp;&nbsp;

                            <input type="radio" id="Corporation" name="type_of_entity" value="Corporation" <?php echo e(isset($homepage)? ($homepage['type_of_entity'] == "Corporation") ? 'checked=checked' : '':''); ?>>
                            <label for="Corporation"> Corporation</label>&nbsp;&nbsp;&nbsp;&nbsp;

                            <input type="radio" id="LLC" name="type_of_entity" value="LLC" <?php echo e(isset($homepage)? ($homepage['type_of_entity'] == "LLC") ? 'checked=checked' : '':''); ?>>
                            <label for="LLC"> LLC</label>&nbsp;&nbsp;&nbsp;&nbsp;

                            <input type="radio" id="Other" name="type_of_entity" value="Other" <?php echo e(isset($homepage)? ($homepage['type_of_entity'] == "Other") ? 'checked=checked' : '':''); ?>>
                            <label for="Other"> Other</label>&nbsp;&nbsp;&nbsp;&nbsp;
                        </div>
                    </div>

                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Email <span class="text-danger">*</span></span>

                            <input type="email" class="form-control" placeholder="Email " name="business_email" required value="<?php echo e(old('business_email', isset($homepage) ? $homepage['business_email']:'')); ?>">

                            <?php $__errorArgs = ['business_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12 col-md-8">
                        <div class="form-group">
                            <span class="">Type of Business (circle all that apply) <span class="text-danger">*</span></span>
                            <br>
                            <input type="checkbox" id="RetailMOTO" name="type_of_business[]" value="Retail MO/TO" <?php echo e(isset($homepage)? in_array("Retail MO/TO" , json_decode($homepage['type_of_business']))? 'checked' : '':''); ?>>
                            <label for="RetailMOTO">Retail MO/TO</label>&nbsp;&nbsp;&nbsp;

                            <input type="checkbox" id="Wholesale" name="type_of_business[]" value="Wholesale" <?php echo e(isset($homepage)? (in_array("Wholesale", json_decode($homepage['type_of_business'])))? 'checked' : '':''); ?>>
                            <label for="Wholesale"> Wholesale</label>&nbsp;&nbsp;&nbsp;&nbsp;

                            <input type="checkbox" id="Restaurant" name="type_of_business[]" value="Restaurant" <?php echo e(isset($homepage)? (in_array("Restaurant",json_decode($homepage['type_of_business'])))? 'checked' : '':''); ?>>
                            <label for="Restaurant"> Restaurant</label>&nbsp;&nbsp;&nbsp;&nbsp;

                            <input type="checkbox" id="Supermarket" name="type_of_business[]" value="Supermarket" <?php echo e(isset($homepage)? (in_array("Supermarket",json_decode($homepage['type_of_business'])))? 'checked' : '':''); ?>>
                            <label for="Supermarket"> Supermarket</label>&nbsp;&nbsp;&nbsp;&nbsp;

                            <input type="checkbox" id="Service" name="type_of_business[]" value="Service" <?php echo e(isset($homepage)? (in_array("Service", json_decode($homepage['type_of_business'])))? 'checked' : '':''); ?>>
                            <label for="Service"> Service</label>&nbsp;&nbsp;&nbsp;&nbsp;

                            <input type="checkbox" id="Other" name="type_of_business[]" value="Other" <?php echo e(isset($homepage)? (in_array("Other",json_decode($homepage['type_of_business'])))? 'checked' : '':''); ?>>
                            <label for="Other"> Other</label>&nbsp;&nbsp;&nbsp;&nbsp;
                        </div>
                    </div>
                    
                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Product/Service Sold<span class="text-danger">*</span></span>
                            <input value="<?php echo e(old('service_sold', isset($homepage) ? $homepage['service_sold']:'')); ?>" type="text" class="form-control" placeholder="Service sold" required name="service_sold">
                            <?php $__errorArgs = ['service_sold'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="checkout_pagination d-flex  justify-content-end">
                            <button type="submit" class="btn btn-primary mt-2 ml-2 text-right">Next</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Personal\merchant-step4\resources\views/pages/step1.blade.php ENDPATH**/ ?>