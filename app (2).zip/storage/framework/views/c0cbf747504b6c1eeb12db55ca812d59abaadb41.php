<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\Session;

if (Session::has('merchant')) {
    $merchant = Session::get('merchant');
}
?>
<section>
    <div class="container">
        <div class="text-center">
            <div class="row">
                <div class="col-12">
                    <h3 class="font-weight-bold">4 steps to funding</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <p class="text-center">Thank you for placing your trust in us. Please take a few minutes to
                    complete the form below. We will process your request in 24-48 business hours.</p>
                </div>
            </div>
        </div>
        <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>

<!-- Checkout Steps Area -->
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="checkout_steps_area">
                <a href="#">BUSINESS INFORMATION</a>
                <a class="active" href="#">MERCHANT/OWNER INFORMATION</a>
                <a href="#">PARTNER /OWNER INFORMATION</a>
                <a href="#">BUSINESS PROPERTY INFORMATION</a>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <form action="<?php echo e(route('submit_second_step')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="checkout_area section_padding_100_50">
            <div class="container">
                <div class="row mt-5">
                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Corporate Officer/Owner Name <span class="text-danger">*</span></span>

                            <input type="text" class="form-control" placeholder="Corporate Officer/Owner Name" name="merchant_owner_name" required value="<?php echo e(old('merchant_owner_name', isset($merchant) ? $merchant['merchant_owner_name']:'')); ?>">

                            <?php $__errorArgs = ['merchant_owner_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Title <span class="text-danger">*</span></span>

                            <input type="text" class="form-control" placeholder="Title " name="merchant_title" required value="<?php echo e(old('merchant_title', isset($merchant) ? $merchant['merchant_title']:'')); ?>">

                            <?php $__errorArgs = ['merchant_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12 col-md-4">
                        <div class="form-group">
                            <span class="">Ownership %<span class="text-danger">*</span></span>
                            <input type="number" class="form-control" placeholder="Ownership %" name="merchant_ownership" required value="<?php echo e(old('merchant_ownership',isset($merchant) ? $merchant['merchant_ownership'] :'')); ?>">
                            <?php $__errorArgs = ['merchant_ownership'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12 col-md-6">
                        <div class="form-group">
                            <span class="">Home Address <span class="text-danger">*</span></span>
                            <textarea type="textarea" class="form-control" placeholder="Home Address" name="merchant_home_address" required>
                                <?php echo e(old('merchant_home_address',isset($merchant) ? $merchant['merchant_home_address'] :'')); ?>

                            </textarea>
                            <?php $__errorArgs = ['merchant_home_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12 col-md-2">
                        <div class="form-group">
                            <span class="">City <span class="text-danger">*</span></span>

                            <input type="text" class="form-control" placeholder="City" name="merchant_city" required value="<?php echo e(old('merchant_city', isset($merchant) ? $merchant['merchant_city']:'')); ?>">

                            <?php $__errorArgs = ['merchant_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="form-group">
                            <span class="">State <span class="text-danger">*</span></span>

                            <input type="text" class="form-control" placeholder="State" name="merchant_state" required value="<?php echo e(old('merchant_state', isset($merchant) ? $merchant['merchant_state']:'')); ?>">

                            <?php $__errorArgs = ['merchant_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="form-group">
                            <span class="">Zip <span class="text-danger">*</span></span>

                            <input type="text" class="form-control" placeholder="Zip" name="merchant_zip" required value="<?php echo e(old('merchant_zip', isset($merchant) ? $merchant['merchant_zip']:'')); ?>">
                            <?php $__errorArgs = ['merchant_zip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12 col-md-3">
                        <div class="form-group">
                            <span class="">SSN<span class="text-danger">*</span></span>
                            <input type="text" class="form-control" placeholder="SSN" name="merchant_ssn"
                            required value="<?php echo e(old('merchant_ssn',isset($merchant) ? $merchant['merchant_ssn'] :'')); ?>">
                            <?php $__errorArgs = ['merchant_ssn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-3">
                        <div class="form-group">
                            <span class="">Date of Birth<span class="text-danger">*</span></span>
                            <input type="date" class="form-control" placeholder="Date of Birth" required
                            name="merchant_date_of_birth" value="<?php echo e(old('merchant_date_of_birth', isset($merchant) ? $merchant['merchant_date_of_birth'] :'')); ?>">
                            <?php $__errorArgs = ['merchant_date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-3">
                        <div class="form-group">
                            <span class="">Home # <span class="text-danger">*</span></span>

                            <input type="text" class="form-control" placeholder="Home " name="merchant_home" required value="<?php echo e(old('merchant_home', isset($merchant) ? $merchant['merchant_home']:'')); ?>">
                            <?php $__errorArgs = ['merchant_home'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12 col-md-3">
                        <div class="form-group">
                            <span class="">Cell #<span class="text-danger">*</span></span>
                            <input type="number" class="form-control" placeholder="Cell Phone" name="merchant_phone_no"
                            required value="<?php echo e(old('merchant_phone_no',isset($merchant) ? $merchant['merchant_phone_no'] :'')); ?>">
                            <?php $__errorArgs = ['merchant_phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="checkout_pagination d-flex  justify-content-end">
                            <a href="<?php echo e(route('home_page')); ?>" class="btn btn-primary mt-2 ml-2">Previous</a>
                            <button type="submit" class="btn btn-primary mt-2 ml-2 text-right">Next</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Personal\merchant-step4\resources\views/pages/step2.blade.php ENDPATH**/ ?>