<?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" id="alert" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <span><?php echo Session::get('success'); ?></span>
        </div>

        <?php elseif(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" id="alert" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            
            <ul>
                <li><?php echo Session::get('error'); ?></li>
            </ul>
        </div>
    <?php endif; ?><?php /**PATH E:\laragon\www\Personal\merchant-step4\resources\views/partials/msg.blade.php ENDPATH**/ ?>